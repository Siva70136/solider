import offline from '../../assets/images/offline.png'
import online from '../../assets/images/online.png'
import './index.css'


const Side = () => {
    return (
        <div className='side-container'>
            <div className='text-container'>
                <div className='logo-container1'>
                    <img src='https://res.cloudinary.com/dcf6kyeeu/image/upload/v1712303241/solider/yden0l7gj8qdarhcbtfp.png' alt="logo" className='logo1' />

                </div>
                <img src='https://res.cloudinary.com/dcf6kyeeu/image/upload/v1712359450/solider/knw4z3mvsm07lslcupxw.png' alt='name' className='battle' />
            </div>
            <div className="images-container1">
                <div className='box'>
                    <img src='https://res.cloudinary.com/dcf6kyeeu/image/upload/v1712305724/solider/ckfnozbcshxqxcyiik9i.png' alt='thor' className='squad' />
                    <img src="https://res.cloudinary.com/dcf6kyeeu/image/upload/v1712305724/solider/hlytflrxgeipwxnhpzdc.png" alt='lady' className='side-img' />
                </div>
                <div className='box'>
                    <img src={online} alt='online' className='squad' />
                    <img src="https://res.cloudinary.com/dcf6kyeeu/image/upload/v1712305725/solider/eljxmajw3rpg5l6mrggd.png" alt='lady' className='side-img' />
                </div>
                <div className='box'>
                    <img src={offline} alt='offline' className='squad' />
                    <img src='https://res.cloudinary.com/dcf6kyeeu/image/upload/v1712305724/solider/hfxw83edrjbmokdawff5.png' alt='thor' className='side-img' />
                </div>


            </div>
        </div>
    )
}
export default Side;